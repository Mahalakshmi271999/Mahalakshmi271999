import { LightningElement, api, wire } from 'lwc';
import { getRecord, getFieldValue } from 'lightning/uiRecordApi';

export default class OppFlameLevel extends LightningElement {
    @api size;
    @api numberOfStars;
    @api readOnlyStar;
    @api disabled;
    @api recordId;
    fields = ['Opportunity.Name','Opportunity.Flame_Calculation__c']

    @wire(getRecord, { recordId: '$recordId', fields: '$fields'})
    opportunityRec;

    get rating() {
        return getFieldValue(this.opportunityRec.data, 'Opportunity.Flame_Calculation__c');
    }
}